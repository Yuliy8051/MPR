package pl.edu.pjwstk.MyRestController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyRestControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
