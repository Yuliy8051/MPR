package pl.edu.pjwstk.MyRestController;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyRestControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyRestControllerApplication.class, args);
	}

}
