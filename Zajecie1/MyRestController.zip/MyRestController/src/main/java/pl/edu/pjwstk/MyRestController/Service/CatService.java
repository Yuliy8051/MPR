package pl.edu.pjwstk.MyRestController.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.edu.pjwstk.MyRestController.Repository.CatRepository;
import pl.edu.pjwstk.MyRestController.model.Cat;

import java.util.List;
import java.util.Optional;

@Service
public class CatService {
    private CatRepository repository;

    @Autowired
    public CatService(CatRepository repository){
        this.repository = repository;
        repository.save(new Cat("Richard", "brown"));
        repository.save(new Cat("Tihrik", "gray"));
        repository.save(new Cat("Mishka", "white"));
    }

    public Iterable<Cat> getAll(){
        return this.repository.findAll();
    }

    public List<Cat> getByName(String name){
        return this.repository.findByName(name);
    }

    public List<Cat> getByColor(String color) {
        return this.repository.findByColor(color);
    }
    public Optional<Cat> getById(Long id){
        return this.repository.findById(id);
    }

    public void addCat(Cat cat){
        this.repository.save(cat);
    }

    public void upgradeById(Long id, Cat cat){
        if (this.repository.findById(id).isPresent()){
            Cat existingCat = this.repository.findById(id).get();
            if (cat.getName() != null)
                existingCat.setName(cat.getName());
            if (cat.getColor() != null)
                existingCat.setColor(cat.getColor());
            existingCat.setIdentifier();
            this.repository.save(existingCat);
        }
    }

    public void deleteById(Long id){
        this.repository.deleteById(id);
    }
}
